import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { RepoProvider } from './Components/RepoContext';
import 'bootstrap/dist/css/bootstrap.min.css';


ReactDOM.render(
  <React.StrictMode>
    <RepoProvider>
      <App />
    </RepoProvider>
  </React.StrictMode>,
  document.getElementById('root')
);
