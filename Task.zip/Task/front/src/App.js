import React from 'react'
import RepoSearch from './Components/RepoSearch'

const App = () => {
  return (

    <div>
      <RepoSearch />
    </div>
  )
}

export default App