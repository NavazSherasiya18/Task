import React from 'react';
import { useRepoContext } from './RepoContext';
import './style/RepoSearch.css'; 

const RepoSearch = () => {
  const { searchTerm, setSearchTerm, repos, page, setPage, totalCount, loading, error, fetchRepos } = useRepoContext();

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1); 
    fetchRepos();
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
    fetchRepos();
  };

  const totalPages = Math.ceil(totalCount / 10);
  const pageLimit = 4;
  const startPage = Math.max(1, page - Math.floor(pageLimit / 2));
  const endPage = Math.min(totalPages, startPage + pageLimit - 1);

  const pages = [];
  for (let i = startPage; i <= endPage; i++) {
    pages.push(i);
  }

  return (
    <div className="repo-search-container">
      <h1 className="mb-4">GitHub Repository Search</h1>
      <form onSubmit={handleSearch} className="search-form mb-4">
        <div className="form-group">
          <label htmlFor="searchTerm" className="form-label">Search Repositories</label>
          <input
            id="searchTerm"
            type="text"
            className="form-control"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary mt-2">Search</button>
      </form>

      {loading && <div className="alert alert-info">Loading...</div>}
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="repo-list">
        {repos.map((repo) => (
          <div key={repo.id} className="repo-card">
            <a href={repo.html_url} target="_blank" rel="noopener noreferrer" className="repo-link">
              <h3 className="repo-name">{repo.name}</h3>
            </a>
            <p className="repo-description">
              {repo.description || 'No description available'} - ⭐ {repo.stargazers_count} - 🍴 {repo.forks_count}
            </p>
          </div>
        ))}
      </div>

      {repos.length > 0 && (
        <nav aria-label="Page navigation">
          <ul className="pagination">
            {page > 1 && (
              <li className="page-item">
                <button className="page-link" onClick={() => handlePageChange(page - 1)}>Previous</button>
              </li>
            )}
            {pages.map((p) => (
              <li key={p} className={`page-item ${p === page ? 'active' : ''}`}>
                <button className="page-link" onClick={() => handlePageChange(p)}>{p}</button>
              </li>
            ))}
            {endPage < totalPages && (
              <li className="page-item">
                <button className="page-link" onClick={() => handlePageChange(page + 1)}>Next</button>
              </li>
            )}
          </ul>
        </nav>
      )}
    </div>
  );
};

export default RepoSearch;
