// src/RepoContext.js
import React, { createContext, useState, useContext, useCallback } from 'react';
import axios from 'axios';

const RepoContext = createContext();

export const useRepoContext = () => useContext(RepoContext);

export const RepoProvider = ({ children }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [repos, setRepos] = useState([]);
  const [page, setPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchRepos = useCallback(async () => {
    if (!searchTerm) {
      setError('Please enter a search term');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`https://api.github.com/search/repositories`, {
        params: { q: searchTerm, page },
      });
      setRepos(response.data.items);
      setTotalCount(response.data.total_count);
    } catch (err) {
      setError('Error fetching repositories');
    }
    setLoading(false);
  }, [searchTerm, page]);

  return (
    <RepoContext.Provider value={{ searchTerm, setSearchTerm, repos, page, setPage, totalCount, loading, error, fetchRepos }}>
      {children}
    </RepoContext.Provider>
  );
};
