const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const port = 5000;

// Use CORS to allow requests from the frontend
app.use(cors());


app.get('/api/search', async (req, res) => {
  const searchTerm = req.query.q;
  const page = req.query.page || 1;
  const perPage = 10;
  
  if (!searchTerm) {
    return res.status(400).json({ message: 'Search term is required' });
  }
  
  try {
    const response = await axios.get(`https://api.github.com/search/repositories`, {
      params: { q: searchTerm, per_page: perPage, page },
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching data from GitHub' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
